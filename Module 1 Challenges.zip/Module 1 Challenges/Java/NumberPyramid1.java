public class NumberPyramid1 {
    public static void main(String[] args) {
        int rows = 5; // Change the number of rows as needed
        printNumberPyramid(rows);
    }

    public static void printNumberPyramid(int rows) {
        for (int i = 1; i <= rows; i++) {
            // Print spaces
            for (int j = 1; j <= rows - i; j++) {
                System.out.print("   "); // Three spaces for better formatting
            }
            // Print numbers
            for (int k = 1; k <= i * 2 - 1; k++) {
                System.out.print((rows - i + 1) + " "); // Print the number
            }
            System.out.println();
        }
    }
}
