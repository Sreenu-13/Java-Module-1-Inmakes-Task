public class NumberPyramid {
    public static void main(String[] args) {
        int rows = 6; // Change the number of rows as needed
        printNumberPyramid(rows);
    }

    public static void printNumberPyramid(int rows) {
        int number = 1;
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(number + " ");
                number++;
            }
            System.out.println();
        }
    }
}
