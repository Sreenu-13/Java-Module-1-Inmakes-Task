public class LetterPattern 
  {
    public static void main(String[] args)
      {
        int rows = 5;
        int v = rows;
        char c = 'A';

        for (int i = 1; i <= rows; i++)
         {
           for (int j = 1; j < i; j++) 
              {
                System.out.print(" ");
            }

           
            for (int k = 1; k <= v; k++)
              {
                System.out.print(c++ + " ");
            }
            c = 'A';
            v--;
            System.out.println();
        }
    }
}
