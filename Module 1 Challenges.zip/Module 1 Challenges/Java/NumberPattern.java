public class NumberPattern 
  {
    public static void main(String[] args) 
      {
        int rows = 5;
        printNumberPattern(rows);
    }

    public static void printNumberPattern(int rows) 
      {
        for (int i = rows; i >= 1; i--) 
        {
          for (int j = 1; j <= rows; j++)
            {
              System.out.print(i + " ");
            }
            System.out.println();
        }
    }
}
