public class StarPyramid 
  {
    public static void main(String[] args) 
      {
        int rows = 5; // Change the number of rows as needed
        printStarPyramid(rows);
      }

       public static void printStarPyramid(int rows) 
       {
         for (int i = 0; i < rows; i++) 
          {
           
            for (int j = 0; j < i; j++) 
              {
                System.out.print("  ");
              }
           
            for (int k = 0; k < 2 * (rows - i) - 1; k++) 
              {
                System.out.print("* ");
             }
            System.out.println(); // Move to the next line
        }
    }
}
